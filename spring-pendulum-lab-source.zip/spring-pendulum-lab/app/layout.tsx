import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://spring-pendulum-lab.waterdownstream.chatgpt.site"),
  title: "Coupled Dynamics 3D Lab",
  description: "Explore a cart–spring pendulum and a bead on a rotating hoop through interactive nonlinear 3D simulations.",
  openGraph: {
    title: "Coupled Dynamics 3D Lab",
    description: "Spring–pendulum and rotating-hoop mechanics, simulated in interactive 3D.",
    type: "website",
    images: [{ url: "/og.png", width: 1672, height: 941, alt: "A cart–spring pendulum beside a bead on a rotating hoop" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Coupled Dynamics 3D Lab",
    description: "Spring–pendulum and rotating-hoop mechanics, simulated in interactive 3D.",
    images: ["/og.png"],
  },
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
