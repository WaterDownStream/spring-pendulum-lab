"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import HoopLab from "./hoop-lab";

type Params = { M: number; m: number; k: number; L: number; g: number; cartDamping: number; pivotDamping: number };
type State = { x: number; vx: number; theta: number; omega: number; t: number };
type Sample = { t: number; x: number; theta: number; energy: number };

const DEFAULTS: Params = { M: 2, m: 0.45, k: 8, L: 1.25, g: 9.81, cartDamping: 0.12, pivotDamping: 0.025 };
const INITIAL: State = { x: 0.42, vx: 0, theta: 28 * Math.PI / 180, omega: 0, t: 0 };

function accelerations(s: State, p: Params) {
  const { x, vx, theta: q, omega: w } = s;
  const c = Math.cos(q), sn = Math.sin(q);
  const A = p.M + p.m;
  const B = p.m * p.L * c;
  const D = p.L * c;
  const E = p.L * p.L;
  const C = -p.k * x - p.cartDamping * vx + p.m * p.L * w * w * sn;
  const F = -p.g * p.L * sn - (p.pivotDamping / p.m) * w;
  const det = A * E - B * D;
  return { ax: (C * E - B * F) / det, alpha: (A * F - D * C) / det };
}

function derivative(s: State, p: Params) {
  const a = accelerations(s, p);
  return { x: s.vx, vx: a.ax, theta: s.omega, omega: a.alpha, t: 1 };
}

function shifted(s: State, d: ReturnType<typeof derivative>, h: number): State {
  return { x: s.x + d.x * h, vx: s.vx + d.vx * h, theta: s.theta + d.theta * h, omega: s.omega + d.omega * h, t: s.t + h };
}

function rk4(s: State, dt: number, p: Params): State {
  const a = derivative(s, p);
  const b = derivative(shifted(s, a, dt / 2), p);
  const c = derivative(shifted(s, b, dt / 2), p);
  const d = derivative(shifted(s, c, dt), p);
  return {
    x: s.x + dt * (a.x + 2 * b.x + 2 * c.x + d.x) / 6,
    vx: s.vx + dt * (a.vx + 2 * b.vx + 2 * c.vx + d.vx) / 6,
    theta: s.theta + dt * (a.theta + 2 * b.theta + 2 * c.theta + d.theta) / 6,
    omega: s.omega + dt * (a.omega + 2 * b.omega + 2 * c.omega + d.omega) / 6,
    t: s.t + dt,
  };
}

function energy(s: State, p: Params) {
  const kinetic = 0.5 * (p.M + p.m) * s.vx ** 2 + p.m * p.L * s.vx * s.omega * Math.cos(s.theta) + 0.5 * p.m * p.L ** 2 * s.omega ** 2;
  return kinetic + 0.5 * p.k * s.x ** 2 + p.m * p.g * p.L * (1 - Math.cos(s.theta));
}

type P3 = { x: number; y: number; z: number };

function Scene({ sim, params, running, onSetState }: { sim: State; params: Params; running: boolean; onSetState: (patch: Partial<State>) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const view = useRef({ yaw: -0.62, pitch: 0.42, zoom: 1, dragging: false, px: 0, py: 0 });
  const dragMode = useRef<"orbit" | "cart" | "bob" | null>(null);
  const hit = useRef({ cartX: 0, cartY: 0, bobX: 0, bobY: 0 });

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(devicePixelRatio || 1, 2);
    if (canvas.width !== Math.round(rect.width * dpr) || canvas.height !== Math.round(rect.height * dpr)) {
      canvas.width = Math.round(rect.width * dpr); canvas.height = Math.round(rect.height * dpr);
    }
    const ctx = canvas.getContext("2d")!;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const W = rect.width, H = rect.height;
    ctx.clearRect(0, 0, W, H);
    const v = view.current;
    const scale = Math.min(W / 7.5, H / 4.8) * v.zoom;
    const cy = Math.cos(v.yaw), sy = Math.sin(v.yaw), cp = Math.cos(v.pitch), sp = Math.sin(v.pitch);
    const project = (p: P3) => {
      const x1 = cy * p.x - sy * p.z;
      const z1 = sy * p.x + cy * p.z;
      const y2 = cp * p.y - sp * z1;
      const z2 = sp * p.y + cp * z1;
      const persp = 1 / Math.max(0.58, 1 + z2 * 0.055);
      return { x: W * 0.54 + x1 * scale * persp, y: H * 0.53 - y2 * scale * persp, z: z2, s: persp };
    };
    const line = (pts: P3[], color: string, width = 1, dash: number[] = []) => {
      const q = pts.map(project); ctx.beginPath(); ctx.moveTo(q[0].x, q[0].y); q.slice(1).forEach(a => ctx.lineTo(a.x, a.y));
      ctx.strokeStyle = color; ctx.lineWidth = width; ctx.setLineDash(dash); ctx.stroke(); ctx.setLineDash([]);
    };
    const poly = (pts: P3[], fill: string, stroke = "rgba(255,255,255,.12)") => {
      const q = pts.map(project); ctx.beginPath(); ctx.moveTo(q[0].x, q[0].y); q.slice(1).forEach(a => ctx.lineTo(a.x, a.y)); ctx.closePath(); ctx.fillStyle = fill; ctx.fill(); ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.stroke();
    };

    const bg = ctx.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, "#11181d"); bg.addColorStop(1, "#070a0c"); ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
    for (let gx = -4; gx <= 4; gx += .5) line([{x:gx,y:-.48,z:-2},{x:gx,y:-.48,z:2}], gx === 0 ? "rgba(93,216,255,.18)" : "rgba(255,255,255,.045)", gx === 0 ? 1.4 : 1);
    for (let gz = -2; gz <= 2; gz += .5) line([{x:-4,y:-.48,z:gz},{x:4,y:-.48,z:gz}], "rgba(255,255,255,.045)");

    poly([{x:-3.35,y:-.48,z:-.75},{x:-3.35,y:1.42,z:-.75},{x:-3.35,y:1.42,z:.75},{x:-3.35,y:-.48,z:.75}], "#151d22", "#30404a");
    line([{x:-3.35,y:.34,z:-.62},{x:-3.35,y:.34,z:.62}], "#94a3ad", 4);
    line([{x:-3.25,y:-.27,z:-.4},{x:3.55,y:-.27,z:-.4}], "#75838c", 5);
    line([{x:-3.25,y:-.27,z:.4},{x:3.55,y:-.27,z:.4}], "#3d4b53", 5);
    for (let xx=-3; xx<=3.4; xx+=.45) line([{x:xx,y:-.31,z:-.48},{x:xx,y:-.31,z:.48}], "#28343a", 2);

    const cartX = sim.x;
    const spring: P3[] = [{x:-3.33,y:.36,z:0},{x:-2.92,y:.36,z:0}];
    const springEnd = cartX - .72;
    const turns = 13, N = 130;
    for (let i=0;i<=N;i++) { const u=i/N; const taper=Math.min(1,u*8,(1-u)*8); spring.push({x:-2.92+(springEnd+2.92)*u,y:.36+.15*Math.sin(turns*2*Math.PI*u)*taper,z:.15*Math.cos(turns*2*Math.PI*u)*taper}); }
    line(spring, "#f0a93c", 3.1);

    const sh = project({x:cartX,y:-.46,z:0}); ctx.save(); ctx.translate(sh.x,sh.y); ctx.scale(1,.25); const rg=ctx.createRadialGradient(0,0,0,0,0,scale*.75); rg.addColorStop(0,"rgba(0,0,0,.5)"); rg.addColorStop(1,"rgba(0,0,0,0)"); ctx.fillStyle=rg;ctx.beginPath();ctx.arc(0,0,scale*.75,0,Math.PI*2);ctx.fill();ctx.restore();
    const xl=cartX-.68,xr=cartX+.68,yb=-.08,yt=.82,zf=-.48,zb=.48;
    poly([{x:xl,y:yb,z:zf},{x:xr,y:yb,z:zf},{x:xr,y:yt,z:zf},{x:xl,y:yt,z:zf}], "#27424c");
    poly([{x:xr,y:yb,z:zf},{x:xr,y:yb,z:zb},{x:xr,y:yt,z:zb},{x:xr,y:yt,z:zf}], "#193039");
    poly([{x:xl,y:yt,z:zf},{x:xr,y:yt,z:zf},{x:xr,y:yt,z:zb},{x:xl,y:yt,z:zb}], "#365865");
    line([{x:xl+.12,y:.65,z:zf-.006},{x:xr-.12,y:.65,z:zf-.006}], "rgba(114,226,255,.35)", 2);
    for (const wx of [cartX-.43,cartX+.43]) { const q=project({x:wx,y:-.16,z:-.5});ctx.fillStyle="#0a0d0f";ctx.strokeStyle="#79909b";ctx.lineWidth=2;ctx.beginPath();ctx.arc(q.x,q.y,Math.max(5,scale*.115*q.s),0,Math.PI*2);ctx.fill();ctx.stroke(); }

    const pivot = {x:cartX,y:.08,z:-.53};
    const bob = {x:cartX + params.L*Math.sin(sim.theta), y:.08-params.L*Math.cos(sim.theta), z:-.53};
    line([pivot,bob], "#e5edf1", 3.2);
    const qp=project(pivot), qb=project(bob); hit.current={cartX:project({x:cartX,y:.35,z:zf}).x,cartY:project({x:cartX,y:.35,z:zf}).y,bobX:qb.x,bobY:qb.y};
    ctx.fillStyle="#091216";ctx.strokeStyle="#65d8f3";ctx.lineWidth=3;ctx.beginPath();ctx.arc(qp.x,qp.y,7,0,Math.PI*2);ctx.fill();ctx.stroke();
    const bobR=Math.max(12,scale*.19*qb.s); const grad=ctx.createRadialGradient(qb.x-bobR*.35,qb.y-bobR*.4,1,qb.x,qb.y,bobR);grad.addColorStop(0,"#ffdd82");grad.addColorStop(.35,"#f4a83a");grad.addColorStop(1,"#9b4d13");ctx.fillStyle=grad;ctx.strokeStyle="#ffc861";ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(qb.x,qb.y,bobR,0,Math.PI*2);ctx.fill();ctx.stroke();
    if (running && Math.abs(sim.vx)>.015) { const dir=Math.sign(sim.vx); line([{x:cartX,y:1.03,z:0},{x:cartX+dir*Math.min(.75,.18+Math.abs(sim.vx)*.35),y:1.03,z:0}], "#61d89b", 2); }
    ctx.fillStyle="rgba(225,238,245,.72)";ctx.font="500 11px ui-monospace, SFMono-Regular, monospace";ctx.fillText("DRAG CART OR BOB TO SET INITIAL STATE",16,H-17);
  }, [sim, params, running]);

  useEffect(() => { draw(); const onResize=()=>draw(); window.addEventListener("resize",onResize); return()=>window.removeEventListener("resize",onResize); }, [draw]);

  const pointer = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const r=e.currentTarget.getBoundingClientRect(); return {x:e.clientX-r.left,y:e.clientY-r.top};
  };
  return <canvas ref={canvasRef} className="scene" aria-label="Interactive three-dimensional cart, spring and pendulum simulation"
    onPointerDown={e=>{const p=pointer(e),h=hit.current; if(Math.hypot(p.x-h.bobX,p.y-h.bobY)<34)dragMode.current="bob";else if(Math.hypot(p.x-h.cartX,p.y-h.cartY)<65)dragMode.current="cart";else dragMode.current="orbit";view.current.dragging=true;view.current.px=p.x;view.current.py=p.y;e.currentTarget.setPointerCapture(e.pointerId)}}
    onPointerMove={e=>{if(!view.current.dragging)return;const p=pointer(e),dx=p.x-view.current.px,dy=p.y-view.current.py; if(dragMode.current==="orbit"){view.current.yaw+=dx*.008;view.current.pitch=Math.max(-.1,Math.min(1.05,view.current.pitch+dy*.006));draw();}else if(dragMode.current==="cart")onSetState({x:Math.max(-1.5,Math.min(1.5,sim.x+dx*.008)),vx:0});else{const cx=hit.current.cartX,cy=hit.current.cartY;onSetState({theta:Math.max(-2.5,Math.min(2.5,Math.atan2(p.x-cx,p.y-cy))),omega:0});}view.current.px=p.x;view.current.py=p.y}}
    onPointerUp={()=>{view.current.dragging=false;dragMode.current=null}}
    onWheel={e=>{e.preventDefault();view.current.zoom=Math.max(.7,Math.min(1.5,view.current.zoom*Math.exp(-e.deltaY*.001)));draw();}}
  />;
}

function Slider({label,value,min,max,step,unit,onChange}: {label:string;value:number;min:number;max:number;step:number;unit:string;onChange:(n:number)=>void}) {
  const pct=(value-min)/(max-min)*100;
  return <label className="sliderRow"><span>{label}</span><output>{value.toFixed(step<.01?3:step<.1?2:1)} {unit}</output><input aria-label={label} type="range" min={min} max={max} step={step} value={value} style={{"--fill":`${pct}%`} as React.CSSProperties} onChange={e=>onChange(Number(e.target.value))}/></label>;
}

function Plot({history}: {history: Sample[]}) {
  const ref=useRef<HTMLCanvasElement>(null);
  useEffect(()=>{const c=ref.current;if(!c)return;const r=c.getBoundingClientRect(),d=Math.min(devicePixelRatio||1,2);c.width=r.width*d;c.height=r.height*d;const x=c.getContext("2d")!;x.setTransform(d,0,0,d,0,0);x.clearRect(0,0,r.width,r.height);const pad={l:34,r:10,t:12,b:24},W=r.width-pad.l-pad.r,H=r.height-pad.t-pad.b;x.strokeStyle="rgba(255,255,255,.07)";x.lineWidth=1;for(let i=0;i<=4;i++){const yy=pad.t+i*H/4;x.beginPath();x.moveTo(pad.l,yy);x.lineTo(pad.l+W,yy);x.stroke()}if(history.length<2)return;const start=history[0].t,end=history.at(-1)!.t, max=Math.max(.4,...history.map(s=>Math.max(Math.abs(s.x),Math.abs(s.theta))));const drawLine=(get:(s:Sample)=>number,col:string)=>{x.beginPath();history.forEach((s,i)=>{const px=pad.l+(s.t-start)/Math.max(.001,end-start)*W,py=pad.t+H/2-get(s)/max*H*.44;i?x.lineTo(px,py):x.moveTo(px,py)});x.strokeStyle=col;x.lineWidth=2;x.stroke()};drawLine(s=>s.x,"#65d8f3");drawLine(s=>s.theta,"#f4ae45");x.fillStyle="#73818a";x.font="10px ui-monospace, monospace";x.fillText(`${Math.max(0,end-start).toFixed(0)} s window`,pad.l,r.height-7);},[history]);
  return <canvas className="plot" ref={ref} aria-label="Live plot of cart displacement and pendulum angle"/>;
}

function SpringLab() {
  const [params,setParams]=useState(DEFAULTS); const paramsRef=useRef(params); paramsRef.current=params;
  const [sim,setSim]=useState(INITIAL); const simRef=useRef(sim); simRef.current=sim;
  const [running,setRunning]=useState(false); const runningRef=useRef(running); runningRef.current=running;
  const [speed,setSpeed]=useState(1); const speedRef=useRef(speed); speedRef.current=speed;
  const [history,setHistory]=useState<Sample[]>([{t:0,x:INITIAL.x,theta:INITIAL.theta,energy:energy(INITIAL,DEFAULTS)}]);
  const acc=accelerations(sim,params), E=energy(sim,params);

  useEffect(()=>{let id=0,last=performance.now(),bucket=0;const frame=(now:number)=>{const real=Math.min(.04,(now-last)/1000);last=now;if(runningRef.current){let s=simRef.current;const total=real*speedRef.current,dt=1/240;let left=total;while(left>0){const h=Math.min(dt,left);s=rk4(s,h,paramsRef.current);left-=h}simRef.current=s;setSim(s);bucket+=real;if(bucket>.055){bucket=0;const sm={t:s.t,x:s.x,theta:s.theta,energy:energy(s,paramsRef.current)};setHistory(h=>[...h,sm].filter(q=>q.t>sm.t-15).slice(-280));}}id=requestAnimationFrame(frame)};id=requestAnimationFrame(frame);return()=>cancelAnimationFrame(id)},[]);
  const reset=()=>{setRunning(false);const s={...INITIAL};simRef.current=s;setSim(s);setHistory([{t:0,x:s.x,theta:s.theta,energy:energy(s,paramsRef.current)}])};
  const patchState=(p:Partial<State>)=>{setRunning(false);const s={...simRef.current,...p};simRef.current=s;setSim(s);setHistory([{t:s.t,x:s.x,theta:s.theta,energy:energy(s,paramsRef.current)}])};
  const setP=(key:keyof Params,v:number)=>{const p={...paramsRef.current,[key]:v};paramsRef.current=p;setParams(p)};
  const tension=params.m*(params.g*Math.cos(sim.theta)+params.L*sim.omega**2-acc.ax*Math.sin(sim.theta));

  return <>
    <section className="workspace">
      <div className="stagePanel">
        <div className="stageMeta"><div><span className="eyebrow">INTERACTIVE 3D MODEL</span><h1>Cart–spring pendulum</h1></div><div className="viewHint">Drag empty space to orbit · Scroll to zoom</div></div>
        <div className="sceneWrap"><Scene sim={sim} params={params} running={running} onSetState={patchState}/><div className="axis"><b>Y</b><span/><em>X</em></div></div>
        <div className="transport"><button className="play" onClick={()=>setRunning(r=>!r)} aria-label={running?"Pause simulation":"Play simulation"}>{running?"Ⅱ":"▶"}</button><button onClick={reset} aria-label="Reset simulation">↺</button><label className="speed">SPEED<select value={speed} onChange={e=>setSpeed(Number(e.target.value))}><option value={.25}>0.25×</option><option value={.5}>0.5×</option><option value={1}>1×</option><option value={2}>2×</option></select></label><div className="time"><span>SIMULATION TIME</span><strong>{sim.t.toFixed(2)} s</strong></div></div>
      </div>
      <aside className="controls">
        <div className="panelTitle"><div><span className="eyebrow">SYSTEM PARAMETERS</span><h2>Physical setup</h2></div><button className="textBtn" onClick={()=>{paramsRef.current=DEFAULTS;setParams(DEFAULTS);reset()}}>Defaults</button></div>
        <div className="section"><h3>Mass & geometry</h3><Slider label="Cart mass M" value={params.M} min={.4} max={6} step={.1} unit="kg" onChange={v=>setP("M",v)}/><Slider label="Bob mass m" value={params.m} min={.1} max={2} step={.05} unit="kg" onChange={v=>setP("m",v)}/><Slider label="String length L" value={params.L} min={.4} max={2} step={.05} unit="m" onChange={v=>setP("L",v)}/></div>
        <div className="section"><h3>Forces</h3><Slider label="Spring stiffness k" value={params.k} min={1} max={30} step={.5} unit="N/m" onChange={v=>setP("k",v)}/><Slider label="Gravity g" value={params.g} min={0} max={15} step={.01} unit="m/s²" onChange={v=>setP("g",v)}/><Slider label="Cart damping" value={params.cartDamping} min={0} max={1} step={.01} unit="N·s/m" onChange={v=>setP("cartDamping",v)}/><Slider label="Pivot damping" value={params.pivotDamping} min={0} max={.2} step={.005} unit="N·m·s" onChange={v=>setP("pivotDamping",v)}/></div>
        <div className="section initial"><h3>Initial conditions</h3><label><span>Cart displacement</span><div><input type="number" step=".05" value={sim.x.toFixed(2)} onChange={e=>patchState({x:Number(e.target.value),vx:0})}/><em>m</em></div></label><label><span>Pendulum angle</span><div><input type="number" step="1" value={(sim.theta*180/Math.PI).toFixed(1)} onChange={e=>patchState({theta:Number(e.target.value)*Math.PI/180,omega:0})}/><em>deg</em></div></label></div>
      </aside>
    </section>
    <section className="readouts">
      <div className="plotCard"><div className="cardHead"><div><span className="eyebrow">LIVE RESPONSE · LAST 15 s</span><h2>Motion history</h2></div><div className="legend"><span className="cyan">x cart (m)</span><span className="amber">θ pendulum (rad)</span></div></div><Plot history={history}/></div>
      <div className="metrics"><div><span>Cart position</span><strong>{sim.x>=0?"+":""}{sim.x.toFixed(3)} <small>m</small></strong></div><div><span>Pendulum angle</span><strong>{(sim.theta*180/Math.PI).toFixed(1)}<small>°</small></strong></div><div className={tension<0?"warning":""} title={tension<0?"A string cannot push: the taut-string model is no longer valid in this state.":undefined}><span>String tension</span><strong>{tension.toFixed(2)} <small>N</small></strong>{tension<0&&<small>SLACK-STRING LIMIT</small>}</div><div><span>Total energy</span><strong>{E.toFixed(3)} <small>J</small></strong></div></div>
    </section>
    <section className="model"><div><span className="eyebrow">THE MODEL</span><h2>One system, two coupled coordinates.</h2><p>The pivot moves with the cart, so the bob’s horizontal acceleration pushes back on it. The simulator solves both nonlinear equations together—no small-angle approximation.</p></div><div className="equations"><code>(M+m)ẍ + mL(θ̈ cosθ − θ̇² sinθ) + kx + cₓẋ = 0</code><code>mL²θ̈ + mLẍ cosθ + mgL sinθ + cθθ̇ = 0</code></div></section>
    <footer><span>Taut ideal string · Rigid cart · Horizontal rail</span><span>Energy falls only through the two damping terms.</span></footer>
  </>;
}

export default function Home(){
  const [system,setSystem]=useState<"spring"|"hoop">("spring");
  return <main>
    <header className="topbar"><div className="brand"><span className="brandMark">D3</span><div><strong>Coupled Dynamics 3D Lab</strong><small>Interactive analytical mechanics</small></div></div><div className="status"><i className="live"/>2 SYSTEMS<span>RK4 · 240 Hz</span></div></header>
    <nav className="systemNav" aria-label="Choose a physical system">
      <button className={system==="spring"?"active":""} aria-pressed={system==="spring"} onClick={()=>setSystem("spring")}><b>01</b><span>Cart–spring pendulum<small>Coupled nonlinear oscillator</small></span></button>
      <button className={system==="hoop"?"active":""} aria-pressed={system==="hoop"} onClick={()=>setSystem("hoop")}><b>02</b><span>Rotating hoop<small>Bead, bifurcation & stability</small></span></button>
    </nav>
    {system==="spring"?<SpringLab/>:<HoopLab/>}
  </main>
}
