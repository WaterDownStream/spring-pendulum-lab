"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type Params = { m: number; R: number; Omega: number; g: number; damping: number };
type State = { theta: number; omega: number; phase: number; t: number };
type Sample = { t: number; theta: number; energy: number };
type P3 = { x: number; y: number; z: number };

const DEFAULTS: Params = { m: .35, R: 1.3, Omega: 3.4, g: 9.81, damping: .04 };
const INITIAL: State = { theta: 22 * Math.PI / 180, omega: 0, phase: 0, t: 0 };

function acceleration(s: State, p: Params) {
  return Math.sin(s.theta) * (p.Omega ** 2 * Math.cos(s.theta) - p.g / p.R) - p.damping * s.omega;
}

function rk4(s: State, dt: number, p: Params): State {
  const f = (q: State) => ({ theta: q.omega, omega: acceleration(q,p), phase: p.Omega });
  const sh = (q: State, d: ReturnType<typeof f>, h: number): State => ({theta:q.theta+d.theta*h,omega:q.omega+d.omega*h,phase:q.phase+d.phase*h,t:q.t+h});
  const a=f(s),b=f(sh(s,a,dt/2)),c=f(sh(s,b,dt/2)),d=f(sh(s,c,dt));
  return {
    theta:s.theta+dt*(a.theta+2*b.theta+2*c.theta+d.theta)/6,
    omega:s.omega+dt*(a.omega+2*b.omega+2*c.omega+d.omega)/6,
    phase:(s.phase+dt*(a.phase+2*b.phase+2*c.phase+d.phase)/6)%(Math.PI*2),
    t:s.t+dt
  };
}

function energy(s: State, p: Params) {
  return .5*p.m*p.R**2*s.omega**2 + p.m*p.g*p.R*(1-Math.cos(s.theta)) - .5*p.m*p.R**2*p.Omega**2*Math.sin(s.theta)**2;
}

function Slider({label,value,min,max,step,unit,onChange}:{label:string;value:number;min:number;max:number;step:number;unit:string;onChange:(n:number)=>void}) {
  const pct=(value-min)/(max-min)*100;
  return <label className="sliderRow"><span>{label}</span><output>{value.toFixed(step<.01?3:step<.1?2:1)} {unit}</output><input aria-label={label} type="range" min={min} max={max} step={step} value={value} style={{"--fill":pct+"%"} as React.CSSProperties} onChange={e=>onChange(Number(e.target.value))}/></label>;
}

function Scene({sim,params,running,onSetState}:{sim:State;params:Params;running:boolean;onSetState:(p:Partial<State>)=>void}) {
  const ref=useRef<HTMLCanvasElement>(null);
  const view=useRef({yaw:-.68,pitch:.25,zoom:1,drag:false,px:0,py:0});
  const drag=useRef<"orbit"|"bead"|null>(null);
  const hit=useRef({x:0,y:0,cx:0,cy:0});

  const draw=useCallback(()=>{
    const canvas=ref.current;if(!canvas)return;
    const rect=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);
    if(canvas.width!==Math.round(rect.width*dpr)||canvas.height!==Math.round(rect.height*dpr)){canvas.width=Math.round(rect.width*dpr);canvas.height=Math.round(rect.height*dpr)}
    const ctx=canvas.getContext("2d")!;ctx.setTransform(dpr,0,0,dpr,0,0);
    const W=rect.width,H=rect.height,v=view.current,size=Math.max(1,params.R/1.3),scale=Math.min(W/(5.8*size),H/(4.7*size))*v.zoom;
    const cy=Math.cos(v.yaw),sy=Math.sin(v.yaw),cp=Math.cos(v.pitch),sp=Math.sin(v.pitch);
    const project=(p:P3)=>{const x1=cy*p.x-sy*p.z,z1=sy*p.x+cy*p.z,y2=cp*p.y-sp*z1,z2=sp*p.y+cp*z1,persp=1/Math.max(.6,1+z2*.06);return{x:W*.52+x1*scale*persp,y:H*.52-y2*scale*persp,s:persp,z:z2}};
    const line=(pts:P3[],color:string,width=1,dash:number[]=[] )=>{const q=pts.map(project);ctx.beginPath();ctx.moveTo(q[0].x,q[0].y);q.slice(1).forEach(a=>ctx.lineTo(a.x,a.y));ctx.strokeStyle=color;ctx.lineWidth=width;ctx.setLineDash(dash);ctx.stroke();ctx.setLineDash([])};
    const poly=(pts:P3[],fill:string,stroke="rgba(255,255,255,.12)")=>{const q=pts.map(project);ctx.beginPath();ctx.moveTo(q[0].x,q[0].y);q.slice(1).forEach(a=>ctx.lineTo(a.x,a.y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();ctx.strokeStyle=stroke;ctx.stroke()};
    const bg=ctx.createLinearGradient(0,0,0,H);bg.addColorStop(0,"#101a20");bg.addColorStop(1,"#06090b");ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
    const ground=.3-params.R-.3;
    for(let gx=-3;gx<=3;gx+=.4)line([{x:gx,y:ground,z:-2.2},{x:gx,y:ground,z:2.2}],"rgba(255,255,255,.045)");
    for(let gz=-2.2;gz<=2.2;gz+=.4)line([{x:-3,y:ground,z:gz},{x:3,y:ground,z:gz}],"rgba(255,255,255,.045)");

    const envelope:P3[]=[];for(let i=0;i<=120;i++){const a=i/120*Math.PI*2;envelope.push({x:params.R*Math.cos(a),y:.3,z:params.R*Math.sin(a)})}line(envelope,"rgba(101,216,243,.11)",1,[4,7]);
    line([{x:0,y:ground,z:0},{x:0,y:.3+params.R+.72,z:0}],"#738891",4);
    line([{x:0,y:ground,z:0},{x:0,y:.3+params.R+.72,z:0}],"rgba(101,216,243,.52)",1);

    poly([{x:-.55,y:ground,z:-.42},{x:.55,y:ground,z:-.42},{x:.55,y:ground+.24,z:-.42},{x:-.55,y:ground+.24,z:-.42}],"#263a43");
    poly([{x:.55,y:ground,z:-.42},{x:.55,y:ground,z:.42},{x:.55,y:ground+.24,z:.42},{x:.55,y:ground+.24,z:-.42}],"#14252c");
    poly([{x:-.55,y:ground+.24,z:-.42},{x:.55,y:ground+.24,z:-.42},{x:.55,y:ground+.24,z:.42},{x:-.55,y:ground+.24,z:.42}],"#36525e");

    const arc:P3[]=[];for(let i=0;i<=45;i++){const a=-.4+i/45*1.55;arc.push({x:.54*Math.cos(a),y:.3+params.R+.52,z:.54*Math.sin(a)})}line(arc,"#65d8f3",2.5);
    const ae=arc.at(-1)!,ap=arc.at(-4)!;line([ae,{x:ae.x+(ae.x-ap.x)*1.8,y:ae.y,z:ae.z+(ae.z-ap.z)*1.8}],"#65d8f3",5);

    const ph=sim.phase,hoop:P3[]=[];for(let i=0;i<=180;i++){const a=i/180*Math.PI*2;hoop.push({x:params.R*Math.sin(a)*Math.cos(ph),y:.3-params.R*Math.cos(a),z:params.R*Math.sin(a)*Math.sin(ph)})}
    line(hoop,"#aebdc4",7);line(hoop,"#e8f0f3",2);
    line([{x:0,y:.3-params.R,z:0},{x:0,y:.3+params.R,z:0}],"rgba(243,173,67,.34)",2);
    const bead:P3={x:params.R*Math.sin(sim.theta)*Math.cos(ph),y:.3-params.R*Math.cos(sim.theta),z:params.R*Math.sin(sim.theta)*Math.sin(ph)};
    const qb=project(bead),qc=project({x:0,y:.3,z:0});hit.current={x:qb.x,y:qb.y,cx:qc.x,cy:qc.y};
    const trail:P3[]=[];for(let i=0;i<=80;i++){const a=i/80*Math.PI*2;trail.push({x:params.R*Math.sin(sim.theta)*Math.cos(a),y:bead.y,z:params.R*Math.sin(sim.theta)*Math.sin(a)})}line(trail,"rgba(243,173,67,.16)",1,[3,6]);
    const rad=Math.max(13,scale*.16*qb.s),g=ctx.createRadialGradient(qb.x-rad*.35,qb.y-rad*.4,1,qb.x,qb.y,rad);g.addColorStop(0,"#fff0a5");g.addColorStop(.35,"#f3ad43");g.addColorStop(1,"#833f10");ctx.fillStyle=g;ctx.strokeStyle="#ffd06c";ctx.lineWidth=2;ctx.beginPath();ctx.arc(qb.x,qb.y,rad,0,Math.PI*2);ctx.fill();ctx.stroke();
    const top=project({x:0,y:.3+params.R+.82,z:0});ctx.fillStyle="#65d8f3";ctx.font="700 12px ui-monospace,monospace";ctx.fillText("z",top.x+8,top.y+4);
    ctx.fillStyle="rgba(225,238,245,.72)";ctx.font="500 11px ui-monospace,monospace";ctx.fillText("DRAG BEAD TO SET θ · DRAG SPACE TO ORBIT",16,H-17);
  },[sim,params,running]);

  useEffect(()=>{draw();const resize=()=>draw();window.addEventListener("resize",resize);return()=>window.removeEventListener("resize",resize)},[draw]);
  const point=(e:React.PointerEvent<HTMLCanvasElement>)=>{const r=e.currentTarget.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}};
  return <canvas ref={ref} className="scene" aria-label="Interactive three-dimensional bead on a vertically rotating hoop"
    onPointerDown={e=>{const p=point(e);drag.current=Math.hypot(p.x-hit.current.x,p.y-hit.current.y)<36?"bead":"orbit";view.current.drag=true;view.current.px=p.x;view.current.py=p.y;e.currentTarget.setPointerCapture(e.pointerId)}}
    onPointerMove={e=>{if(!view.current.drag)return;const p=point(e),dx=p.x-view.current.px,dy=p.y-view.current.py;if(drag.current==="orbit"){view.current.yaw+=dx*.008;view.current.pitch=Math.max(-.08,Math.min(1.05,view.current.pitch+dy*.006));draw()}else{const h=hit.current;onSetState({theta:Math.max(-Math.PI+.03,Math.min(Math.PI-.03,Math.atan2(p.x-h.cx,p.y-h.cy))),omega:0})}view.current.px=p.x;view.current.py=p.y}}
    onPointerUp={()=>{view.current.drag=false;drag.current=null}}
    onWheel={e=>{e.preventDefault();view.current.zoom=Math.max(.68,Math.min(1.5,view.current.zoom*Math.exp(-e.deltaY*.001)));draw()}}/>;
}

function Plot({history,equilibrium}:{history:Sample[];equilibrium:number}) {
  const ref=useRef<HTMLCanvasElement>(null);
  useEffect(()=>{const c=ref.current;if(!c)return;const r=c.getBoundingClientRect(),d=Math.min(devicePixelRatio||1,2);c.width=r.width*d;c.height=r.height*d;const x=c.getContext("2d")!;x.setTransform(d,0,0,d,0,0);x.clearRect(0,0,r.width,r.height);const p={l:34,r:10,t:12,b:24},W=r.width-p.l-p.r,H=r.height-p.t-p.b;x.strokeStyle="rgba(255,255,255,.07)";for(let i=0;i<=4;i++){const yy=p.t+i*H/4;x.beginPath();x.moveTo(p.l,yy);x.lineTo(p.l+W,yy);x.stroke()}if(history.length<2)return;const start=history[0].t,end=history.at(-1)!.t,max=Math.max(.45,equilibrium*1.25,...history.map(s=>Math.abs(s.theta)));if(equilibrium>0){for(const sign of [-1,1]){const yy=p.t+H/2-sign*equilibrium/max*H*.44;x.beginPath();x.moveTo(p.l,yy);x.lineTo(p.l+W,yy);x.strokeStyle="rgba(243,173,67,.6)";x.setLineDash([5,5]);x.stroke();x.setLineDash([])}}x.beginPath();history.forEach((s,i)=>{const px=p.l+(s.t-start)/Math.max(.001,end-start)*W,py=p.t+H/2-s.theta/max*H*.44;i?x.lineTo(px,py):x.moveTo(px,py)});x.strokeStyle="#65d8f3";x.lineWidth=2;x.stroke();x.fillStyle="#73818a";x.font="10px ui-monospace,monospace";x.fillText(Math.max(0,end-start).toFixed(0)+" s window",p.l,r.height-7)},[history,equilibrium]);
  return <canvas ref={ref} className="plot" aria-label="Live plot of bead angle and stable equilibrium"/>;
}

export default function HoopLab() {
  const [params,setParams]=useState(DEFAULTS);const pRef=useRef(params);pRef.current=params;
  const [sim,setSim]=useState(INITIAL);const sRef=useRef(sim);sRef.current=sim;
  const [running,setRunning]=useState(false);const runRef=useRef(running);runRef.current=running;
  const [speed,setSpeed]=useState(1);const speedRef=useRef(speed);speedRef.current=speed;
  const [history,setHistory]=useState<Sample[]>([{t:0,theta:INITIAL.theta,energy:energy(INITIAL,DEFAULTS)}]);
  const critical=Math.sqrt(params.g/params.R),eq=params.Omega>critical?Math.acos(params.g/(params.R*params.Omega**2)):0;
  const ratio=params.Omega/critical,regime=ratio<.98?"SINGLE STABLE MINIMUM":ratio>1.02?"BROKEN-SYMMETRY PAIR":"NEAR CRITICAL SPEED";

  useEffect(()=>{let id=0,last=performance.now(),bucket=0;const frame=(now:number)=>{const real=Math.min(.04,(now-last)/1000);last=now;if(runRef.current){let s=sRef.current,left=real*speedRef.current;while(left>0){const h=Math.min(1/240,left);s=rk4(s,h,pRef.current);left-=h}sRef.current=s;setSim(s);bucket+=real;if(bucket>.055){bucket=0;const sm={t:s.t,theta:s.theta,energy:energy(s,pRef.current)};setHistory(h=>[...h,sm].filter(q=>q.t>sm.t-15).slice(-280))}}id=requestAnimationFrame(frame)};id=requestAnimationFrame(frame);return()=>cancelAnimationFrame(id)},[]);
  const reset=()=>{setRunning(false);const s={...INITIAL};sRef.current=s;setSim(s);setHistory([{t:0,theta:s.theta,energy:energy(s,pRef.current)}])};
  const patchState=(q:Partial<State>)=>{setRunning(false);const s={...sRef.current,...q};sRef.current=s;setSim(s);setHistory([{t:s.t,theta:s.theta,energy:energy(s,pRef.current)}])};
  const setP=(key:keyof Params,v:number)=>{const p={...pRef.current,[key]:v};pRef.current=p;setParams(p)};

  return <>
    <section className="workspace">
      <div className="stagePanel">
        <div className="stageMeta"><div><span className="eyebrow">INTERACTIVE 3D MODEL · SYSTEM 02</span><h1>Bead on a rotating hoop</h1></div><div className="viewHint">Drag empty space to orbit · Scroll to zoom</div></div>
        <div className="sceneWrap"><Scene sim={sim} params={params} running={running} onSetState={patchState}/><div className="axis"><b>Z</b><span/><em>R</em></div><div className={"regime "+(ratio>1.02?"split":ratio<.98?"single":"critical")}><span>{regime}</span><strong>Ω / Ωc = {ratio.toFixed(2)}</strong></div></div>
        <div className="transport"><button className="play" onClick={()=>setRunning(r=>!r)} aria-label={running?"Pause simulation":"Play simulation"}>{running?"Ⅱ":"▶"}</button><button onClick={reset} aria-label="Reset simulation">↺</button><label className="speed">SPEED<select value={speed} onChange={e=>setSpeed(Number(e.target.value))}><option value={.25}>0.25×</option><option value={.5}>0.5×</option><option value={1}>1×</option><option value={2}>2×</option></select></label><div className="time"><span>SIMULATION TIME</span><strong>{sim.t.toFixed(2)} s</strong></div></div>
      </div>
      <aside className="controls">
        <div className="panelTitle"><div><span className="eyebrow">SYSTEM PARAMETERS</span><h2>Rotating apparatus</h2></div><button className="textBtn" onClick={()=>{pRef.current=DEFAULTS;setParams(DEFAULTS);reset()}}>Defaults</button></div>
        <div className="section"><h3>Bead & geometry</h3><Slider label="Bead mass m" value={params.m} min={.05} max={2} step={.05} unit="kg" onChange={v=>setP("m",v)}/><Slider label="Hoop radius R" value={params.R} min={.5} max={2} step={.05} unit="m" onChange={v=>setP("R",v)}/></div>
        <div className="section"><h3>Drive & forces</h3><Slider label="Drive speed Ω" value={params.Omega} min={0} max={7} step={.05} unit="rad/s" onChange={v=>setP("Omega",v)}/><Slider label="Gravity g" value={params.g} min={0} max={15} step={.01} unit="m/s²" onChange={v=>setP("g",v)}/><Slider label="Angular damping γ" value={params.damping} min={0} max={.8} step={.01} unit="s⁻¹" onChange={v=>setP("damping",v)}/></div>
        <div className="section initial hoopInitial"><h3>Initial conditions</h3><label><span>Bead angle θ</span><div><input type="number" step="1" value={(sim.theta*180/Math.PI).toFixed(1)} onChange={e=>patchState({theta:Number(e.target.value)*Math.PI/180,omega:0})}/><em>deg</em></div></label><label><span>Angular velocity</span><div><input type="number" step=".1" value={sim.omega.toFixed(2)} onChange={e=>patchState({omega:Number(e.target.value)})}/><em>rad/s</em></div></label></div>
        <div className="bifurcation"><span>CRITICAL THRESHOLD</span><strong>Ωc = √(g/R) = {critical.toFixed(2)} rad/s</strong><p>{ratio>1?"The bottom is unstable. The bead chooses one of two stable angles.":"Gravity keeps the bottom as the only stable equilibrium."}</p></div>
      </aside>
    </section>
    <section className="readouts">
      <div className="plotCard"><div className="cardHead"><div><span className="eyebrow">LIVE RESPONSE · LAST 15 s</span><h2>Angular motion</h2></div><div className="legend"><span className="cyan">θ bead (rad)</span><span className="amber">stable equilibria</span></div></div><Plot history={history} equilibrium={eq}/></div>
      <div className="metrics"><div><span>Bead angle</span><strong>{(sim.theta*180/Math.PI).toFixed(1)}<small>°</small></strong></div><div><span>Stable angle</span><strong>{eq?"±"+(eq*180/Math.PI).toFixed(1):"0.0"}<small>°</small></strong></div><div><span>Critical speed</span><strong>{critical.toFixed(2)} <small>rad/s</small></strong></div><div><span>Effective energy</span><strong>{energy(sim,params).toFixed(3)} <small>J</small></strong></div></div>
    </section>
    <section className="model"><div><span className="eyebrow">THE MODEL</span><h2>Rotation changes the shape of stability.</h2><p>The motor holds Ω constant. In the rotating frame, gravity pulls the bead down while the centrifugal term pushes it away from the axis. Above Ωc, the central equilibrium does not merely shift—it splits into two.</p></div><div className="equations"><code>θ̈ = sinθ (Ω² cosθ − g/R) − γθ̇</code><code>Ueff(θ) = mgR(1 − cosθ) − ½mR²Ω²sin²θ</code><code>Ω &gt; √(g/R) ⇒ θeq = ±cos⁻¹(g/RΩ²)</code></div></section>
    <footer><span>Smooth rigid hoop · Prescribed constant Ω · Point-mass bead</span><span>Effective energy is defined in the co-rotating frame.</span></footer>
  </>;
}
